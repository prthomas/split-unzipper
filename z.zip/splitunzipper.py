class SplitUnzipper:
    defaultSize = 128 * 1024 * 1024

    def __init__(self, FileStream, SplitSize=defaultSize, HeaderIncl=False):
        self.splitsize = SplitSize
        self.headerincl = HeaderIncl
